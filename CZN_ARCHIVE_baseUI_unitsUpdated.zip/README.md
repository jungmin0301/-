# Chaos Zero: Nightmare Archive (Offline)

정적(Static) + 오프라인 친화 구조입니다.

- 데이터는 `/data/*.json`만 수정하면 화면에 자동 반영됩니다. (소프트코딩)
- DB 필요 없음. 정적 호스팅/로컬 서버로 운영 가능.
- 주의: `fetch()`로 JSON을 읽기 때문에 **파일 더블클릭(file://)** 에서는 막힐 수 있습니다.
  - 로컬에서 볼 때는 정적 서버를 켜세요.

## 로컬 실행(Python)
```bash
cd CZN_ARCHIVE
python -m http.server 5173
```
브라우저에서 `http://localhost:5173`

## 데이터 위치
- 홈 배너/네비: `data/config.json`
- 전투원: `data/units.json`
- 파트너: `data/partners.json`
- 카오스: `data/chaos.json`
- 가이드: `data/guides.json`
- 카드: `data/cards.json`
