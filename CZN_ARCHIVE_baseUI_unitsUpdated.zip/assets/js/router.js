
import { readHash } from './utils.js';
export function matchRoute(){
  const path = readHash();
  const seg = path.split('/').filter(Boolean);
  if(seg.length===0) return {name:'home', params:{}};
  const [a,b] = seg;
  if(a==='units') return {name: b ? 'unitDetail' : 'units', params:{id:b}};
  if(a==='partners') return {name: b ? 'partnerDetail' : 'partners', params:{id:b}};
  if(a==='chaos') return {name: b ? 'chaosDetail' : 'chaos', params:{id:b}};
  if(a==='guides') return {name:'guides', params:{id:b}};
  if(a==='cards') return {name:'cards', params:{}};
  if(a==='deckbuilder') return {name:'deckbuilder', params:{}};
  if(a==='calculator') return {name:'calculator', params:{}};
  return {name:'notfound', params:{}};
}
