
import { $$, closeModal } from './utils.js';
import { getAllData } from './store.js';
import { matchRoute } from './router.js';
import { renderHome, renderUnits, renderUnitDetail, renderPartners, renderPartnerDetail, renderChaos, renderChaosDetail, renderGuides, renderCards, renderDeckbuilder, renderCalculator, renderNotFound } from './views.js';

const view = document.getElementById('view');
const nav = document.getElementById('nav');
const sidebar = document.getElementById('sidebar');

function mountNav(cfg){
  nav.innerHTML = cfg.nav.map(n=>`
    <a href="#${n.path}" data-path="${n.path}">
      <span>${n.label}</span>
      <span class="tag">${n.short || ''}</span>
    </a>
  `).join('');
}

function setActiveNav(path){
  $$('#nav a').forEach(a=> a.classList.toggle('active', a.dataset.path === path));
}

function cleanup(){
  if(view && view._cleanup){
    try{ view._cleanup(); }catch(e){}
    delete view._cleanup;
  }
}

function tickClock(){
  const el = document.getElementById('clock');
  const d = new Date();
  const pad = (n)=>String(n).padStart(2,'0');
  if(el) el.textContent = `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
setInterval(tickClock, 1000); tickClock();

function setupModal(){
  document.getElementById('modal').addEventListener('click', (e)=>{
    if(e.target.dataset.close) closeModal();
  });
  window.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeModal(); });
}

function setupSidebar(){
  document.getElementById('sidebarToggle').addEventListener('click', ()=> sidebar.classList.toggle('open'));
  document.addEventListener('click', (e)=>{
    if(window.innerWidth > 860) return;
    const inSidebar = e.target.closest('.sidebar');
    const toggle = e.target.closest('#sidebarToggle');
    if(!inSidebar && !toggle) sidebar.classList.remove('open');
  });
}

async function render(){
  const data = await getAllData();
  mountNav(data.config);
  setupModal();
  setupSidebar();

  const route = matchRoute();
  const navKey = route.name==='home' ? '/' : (location.hash.replace('#','') || '/');
  setActiveNav('/' + (navKey.split('/').filter(Boolean)[0] || ''));

  cleanup();
  switch(route.name){
    case 'home': renderHome(view, data); break;
    case 'units': renderUnits(view, data); break;
    case 'unitDetail': renderUnitDetail(view, data, route.params.id); break;
    case 'partners': renderPartners(view, data); break;
    case 'partnerDetail': renderPartnerDetail(view, data, route.params.id); break;
    case 'chaos': renderChaos(view, data); break;
    case 'chaosDetail': renderChaosDetail(view, data, route.params.id); break;
    case 'guides': renderGuides(view, data, route.params.id); break;
    case 'cards': renderCards(view, data); break;
    case 'deckbuilder': renderDeckbuilder(view, data); break;
    case 'calculator': renderCalculator(view, data); break;
    default: renderNotFound(view);
  }
}

window.addEventListener('hashchange', ()=>render().catch(err=>{
  console.error(err);
  view.innerHTML = `<div class="card"><div class="section">에러: ${String(err.message||err)}</div></div>`;
}));
render().catch(err=>{
  console.error(err);
  view.innerHTML = `<div class="card"><div class="section">초기 로드 실패: ${String(err.message||err)}</div></div>`;
});
