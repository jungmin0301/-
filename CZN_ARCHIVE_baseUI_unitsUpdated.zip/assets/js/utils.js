
export const $ = (sel, el=document)=>el.querySelector(sel);
export const $$ = (sel, el=document)=>Array.from(el.querySelectorAll(sel));
export function esc(s=''){return String(s).replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));}
export function formatRemaining(ms){
  if(ms <= 0) return '종료';
  const sec = Math.floor(ms/1000);
  const d = Math.floor(sec/86400);
  const h = Math.floor((sec%86400)/3600);
  const m = Math.floor((sec%3600)/60);
  if(d>0) return `${d}일 ${h}시간 남음`;
  if(h>0) return `${h}시간 ${m}분 남음`;
  return `${m}분 남음`;
}
export function nowKST(){ return new Date(); }
export function readHash(){ const raw = location.hash.replace('#','').trim(); return raw || '/'; }
export function setTitle(t){ const el = document.getElementById('pageTitle'); if(el) el.textContent = t; }
export function openModal(title, html){
  const modal = document.getElementById('modal');
  document.getElementById('modalTitle').textContent = title || '';
  document.getElementById('modalBody').innerHTML = html;
  modal.classList.remove('hidden');
}
export function closeModal(){
  const modal = document.getElementById('modal');
  modal.classList.add('hidden');
  document.getElementById('modalBody').innerHTML = '';
}
export function showCtxMenu({x,y, items}){
  const m = document.getElementById('ctxMenu');
  m.innerHTML = items.map((it,idx)=>`
    <div class="item" data-idx="${idx}">
      <div>${esc(it.label)}</div>
      <div class="right">${it.right ? esc(it.right) : ''}</div>
    </div>
  `).join('');
  const pad = 10;
  m.style.left = Math.min(x, window.innerWidth - 260 - pad) + 'px';
  m.style.top = Math.min(y, window.innerHeight - 260 - pad) + 'px';
  m.classList.remove('hidden');

  const onClick = (e)=>{
    const row = e.target.closest('.item');
    if(!row) return;
    const i = Number(row.dataset.idx);
    items[i]?.onClick?.();
    hideCtxMenu();
  };
  const onAny = (e)=>{
    if(e.target.closest('#ctxMenu')) return;
    hideCtxMenu();
  };
  m.addEventListener('click', onClick, {once:false});
  setTimeout(()=>document.addEventListener('mousedown', onAny, {once:true}), 0);
}
export function hideCtxMenu(){
  const m = document.getElementById('ctxMenu');
  m.classList.add('hidden');
  m.innerHTML = '';
}

// Normalize any path into a site-relative asset url (offline-friendly)
export function normalizeAssetPath(p){
  if(!p) return '';
  // already absolute or data url
  if(p.startsWith('http://')||p.startsWith('https://')||p.startsWith('data:')) return p;
  // strip leading ./ or ../
  p = p.replace(/^\.\/,'');
  while(p.startsWith('../')) p = p.slice(3);
  // ensure no leading slash to keep relative hosting working
  if(p.startsWith('/')) p = p.slice(1);
  return p;
}

export function assetUrl(p){
  const n = normalizeAssetPath(p);
  return n || '';
}
