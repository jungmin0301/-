
import { $, $$, esc, formatRemaining, nowKST, openModal, showCtxMenu, setTitle } from './utils.js';


function renderCardThumb(card){
  const img = assetUrl(card.img || '');
  const cost = card.cost ?? '';
  const name = card.name ?? '';
  const type = card.type ?? '';
  const effect = card.effect ?? '';
  return `
    <div class="card-thumb" data-card-id="${esc(card.id||'')}">
      <div class="card-thumb-imgwrap">
        <img class="card-thumb-img" src="${img}" alt="${esc(name||card.id||'card')}" loading="lazy" />
        <div class="card-overlay">
          <div class="card-ol-line">
            <span class="card-ol-cost">${esc(cost)}</span>
            <span class="card-ol-name">${esc(name)}</span>
          </div>
          <div class="card-ol-type">${esc(type)}</div>
        </div>
      </div>
      <div class="card-effect">${esc(effect)}</div>
    </div>
  `.trim();
}

function iconText(t){ return `<div class="cornerIcon">${esc(t)}</div>`; }

export function renderHome(root, data){
  setTitle('홈');
  const cfg = data.config;
  const now = nowKST().getTime();
  const banners = cfg.banners.map(b=>{
    const end = new Date(b.endsAt).getTime();
    return {...b, remaining: end - now};
  });

  root.innerHTML = `
    <div class="grid" style="gap:14px">
      <div class="banner" id="banner">
        <div class="banner__img" id="bannerImg">${esc(banners[0]?.title || 'Banner')}</div>
        <div class="banner__overlay"></div>
        <div class="banner__info">
          <div class="banner__title" id="bannerTitle">${esc(banners[0]?.title || '')}</div>
          <div class="countdown" id="bannerCountdown">⏳ ${esc(formatRemaining(banners[0]?.remaining ?? 0))}</div>
        </div>
      </div>

      <div class="card"><div class="section">
        <h2>바로가기</h2>
        <div class="grid cols-4">
          ${cfg.nav.filter(n=>n.path!=='/').map(n=>`
            <a class="card" href="#${esc(n.path)}" style="padding:14px; display:block">
              <div style="font-weight:900">${esc(n.label)}</div>
              <div class="muted" style="margin-top:4px; font-size:12px">${esc(n.desc || '')}</div>
            </a>
          `).join('')}
        </div>
      </div></div>

      <div class="card"><div class="section">
        <h2>최신 가이드</h2>
        <div class="grid cols-2">
          ${[...data.guides.items].sort((a,b)=> new Date(b.updatedAt) - new Date(a.updatedAt)).slice(0,6).map(g=>`
            <a class="card" href="#/guides/${esc(g.id)}" style="padding:14px; display:block">
              <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start">
                <div style="font-weight:900">${esc(g.title)}</div>
                <span class="badge">${esc(g.tag)}</span>
              </div>
              <div class="muted" style="margin-top:6px; font-size:12px">${esc(g.summary || '')}</div>
              <div class="muted" style="margin-top:8px; font-size:11px">업데이트: ${esc(g.updatedAt)}</div>
            </a>
          `).join('')}
        </div>
      </div></div>

      <div class="card"><div class="section">
        <h2>대균열 보스 기믹</h2>
        <div class="grid cols-2">
          <div class="card" style="padding:14px">
            <div style="font-weight:900">전반기 대균열 (3주차~6주차)</div>
            <div class="muted" style="margin-top:6px; font-size:12px">여기에 전반기 보스 기믹 설명(텍스트/이미지)을 넣습니다.</div>
          </div>
          <div class="card" style="padding:14px">
            <div style="font-weight:900">후반기 대균열 (6주차~9주차)</div>
            <div class="muted" style="margin-top:6px; font-size:12px">여기에 후반기 보스 기믹 설명(텍스트/이미지)을 넣습니다.</div>
          </div>
        </div>
      </div></div>
    </div>
  `;

  let idx = 0;
  function update(){
    const now = nowKST().getTime();
    banners.forEach(b=>b.remaining = new Date(b.endsAt).getTime() - now);
    const cur = banners[idx] || banners[0];
    $('#bannerImg', root).textContent = cur?.title || 'Banner';
    $('#bannerTitle', root).textContent = cur?.title || '';
    $('#bannerCountdown', root).textContent = `⏳ ${formatRemaining(cur?.remaining ?? 0)} · ${cur?.rangeText || ''}`;
  }
  update();
  const t = setInterval(()=>{ idx = (idx+1) % Math.max(1,banners.length); update(); }, 5000);
  root._cleanup = ()=>clearInterval(t);
}

function unitThumb(u){
  const iconA = u.element?.slice(0,1) || '속';
  const iconB = u.job?.slice(0,1) || '직';
  return `
    <div class="thumb" data-id="${esc(u.id)}" title="${esc(u.name)}">
      <div class="thumb__img">${esc(u.name)}</div>
      <div class="cornerIcons">${iconText(iconA)}${iconText(iconB)}</div>
      <div class="thumb__meta">
        <div class="thumb__title">${esc(u.name)} <span class="badge">${esc(u.rarity)}★</span></div>
        <div class="thumb__sub">${esc(u.element)} · ${esc(u.job)}</div>
      </div>
    </div>`;
}

export function renderUnits(root, data, params={}){
  setTitle('전투원');
  const list = data.units.items || [];
  const q = (params.q||'').trim().toLowerCase();
  const element = params.element||'';
  const role = params.role||'';
  const rarity = params.rarity||'';

  const filtered = list.filter(u=>{
    if(q && !((u.name||'').toLowerCase().includes(q) || (u.id||'').toLowerCase().includes(q))) return false;
    if(element && u.element!==element) return false;
    if(role && u.role!==role) return false;
    if(rarity && String(u.rarity)!==String(rarity)) return false;
    return true;
  });

  const elements = ['열정','정의','질서','본능','공허'];
  const roles = ['스트라이커','레인저','뱅가드','헌터','컨트롤러','사이오닉'];
  const rarities = ['5','4'];

  root.innerHTML = `
    <div class="card section">
      <h2>전투원</h2>
      <div class="toolbar">
        <input class="input" id="q" placeholder="검색: 이름" value="${esc(params.q||'')}" />
        <select id="fElement">
          <option value="">속성(전체)</option>
          ${elements.map(e=>`<option value="${esc(e)}" ${e===element?'selected':''}>${esc(e)}</option>`).join('')}
        </select>
        <select id="fRole">
          <option value="">직업(전체)</option>
          ${roles.map(r=>`<option value="${esc(r)}" ${r===role?'selected':''}>${esc(r)}</option>`).join('')}
        </select>
        <select id="fRarity">
          <option value="">성급(전체)</option>
          ${rarities.map(r=>`<option value="${r}" ${r===rarity?'selected':''}>${r}성</option>`).join('')}
        </select>
        <span class="badge">${filtered.length}명</span>
      </div>
      <div class="thumbGrid">
        ${filtered.map(u=>`
          <a class="thumb" href="#units/${esc(u.id)}">
            <img class="thumb__img" src="${assetUrl(u.thumb||'')}" alt="${esc(u.name)}" loading="lazy" onerror="this.classList.add('ph');this.removeAttribute('src');this.alt='';this.outerHTML='<div class=\"thumb__img ph\">NO IMG</div>'"/>
            <div class="cornerIcons">
              ${iconText(u.element||'?')}
              ${iconText(u.role||'?')}
            </div>
            <div class="thumb__meta">
              <div class="thumb__title">${esc(u.name)}</div>
              <div class="thumb__sub">${esc(String(u.rarity||''))}성 · ${esc(u.element||'')} · ${esc(u.role||'')}</div>
            </div>
          </a>
        `).join('')}
      </div>
    </div>
  `;

  const apply = ()=>{
    const next = {
      q: document.getElementById('q').value,
      element: document.getElementById('fElement').value,
      role: document.getElementById('fRole').value,
      rarity: document.getElementById('fRarity').value,
    };
    // router parses query? simplest: encode in hash
    const qp = new URLSearchParams();
    Object.entries(next).forEach(([k,v])=>{ if(v) qp.set(k,v); });
    location.hash = '#units' + (qp.toString()?('?'+qp.toString()):'');
  };
  ['q','fElement','fRole','fRarity'].forEach(id=>{
    const el = document.getElementById(id);
    if(!el) return;
    el.addEventListener(id==='q'?'input':'change', ()=>{
      // debounce lightly
      if(id==='q'){
        window.__unitQTimer && clearTimeout(window.__unitQTimer);
        window.__unitQTimer = setTimeout(apply, 150);
      } else apply();
    });
  });
}


function renderCardMini(c){
  return `
  <div class="miniCard" data-card="${esc(c.id)}" title="hover: 요약 / click: 상세">
    <div class="miniCard__pill">${esc(c.type)} · ${esc(c.cost)}</div>
    <div class="miniCard__title">${esc(c.name)}</div>
    <div class="miniCard__sub">${esc(c.tooltip || c.text || '')}</div>
  </div>`;
}

export function renderUnitDetail(root, data, unitId){
  setTitle('전투원');

  const u = data.units.items.find(x => String(x.id).toLowerCase() === String(unitId).toLowerCase());
  if(!u){
    root.innerHTML = `<div class="empty">없는 유닛입니다.</div>`;
    return;
  }

  // Build card list: base_1..3, spark_1..5, ego
  const unitFolder = esc(u.id);
  const cards = [];
  const pushCard = (id, label, img) => cards.push({
    id, name: label, img,
    cost: '', type: '', effect: ''
  });

  for(let i=1;i<=3;i++){
    pushCard(`base_${i}`, `base_${i}`, `assets/img/cards/${unitFolder}/base_${i}.webp`);
  }
  for(let i=1;i<=5;i++){
    pushCard(`spark_${i}`, `spark_${i}`, `assets/img/cards/${unitFolder}/spark_${i}.webp`);
  }
  pushCard(`ego`, `ego`, `assets/img/cards/${unitFolder}/ego.webp`);

  const faceUrl = assetUrl(u.thumb || `assets/img/face/${unitFolder}.webp`);

  // Spark selection modal
  // Requirement:
  // - spark_1~4: transform exists (5 variants)
  // - spark_5: no transform
  // - Show the SAME spark card image 5 times; variants are distinguished via overlay labels.
  const openSparkPicker = ({ sparkNo, imgSrc, cardName, cardType, cost }) => {
    if(sparkNo >= 5) return;
    const options = Array.from({length:5}, (_,i)=>({
      idx: i+1,
      label: `고유 번뜩임 ${i+1}`,
      img: imgSrc
    }));
    const html = `
      <div class="spark-picker">
        <div class="spark-picker-title">번뜩임 선택</div>
        <div class="spark-picker-grid">
          ${options.map((o)=>`
            <button class="card-thumb spark-opt" data-idx="${o.idx}">
              <div class="card-img-wrap">
                <img class="card-img" src="${assetUrl(o.img)}" alt="spark_${o.idx}">
                <div class="card-overlay">
                  <div class="ov-row">
                    <span class="ov-cost">${esc(String(cost ?? ''))}</span>
                    <span class="ov-name">${esc(cardName || '')}</span>
                    <span class="ov-type">${esc(cardType || '')}</span>
                  </div>
                  <div class="ov-sub">${esc(o.label)}</div>
                </div>
              </div>
            </button>
          `).join('')}
        </div>
        <button class="spark-picker-close" id="sparkClose">닫기</button>
      </div>
    `;
    openModal(html);

    // Store chosen variant (optional)
    const picker = document.querySelector('.spark-picker');
    picker?.addEventListener('click', (e)=>{
      const btn = e.target.closest('.spark-opt');
      if(!btn) return;
      const chosen = Number(btn.dataset.idx || '1');
      store.state = store.state || {};
      store.state.sparkChoices = store.state.sparkChoices || {};
      store.state.sparkChoices[`${u.id}:spark_${sparkNo}`] = chosen;
      closeModal();
    });
    document.getElementById('sparkClose')?.addEventListener('click', ()=>closeModal());
  };

  const cardGrid = cards.map(c=>{
    const isSpark = c.id.startsWith('spark_');
    return `<div class="unit-card-wrap ${isSpark?'is-spark':''}" data-card="${esc(c.id)}">${renderCardThumb(c)}</div>`;
  }).join('');

  root.innerHTML = `
    <div class="detail">
      <div class="detail-hero">
        <img class="detail-face" src="${faceUrl}" alt="${esc(u.name)}" />
        <div class="detail-meta">
          <div class="detail-name">${esc(u.name)}</div>
          <div class="detail-tags">
            <span class="tag">${esc(u.element)}</span>
            <span class="tag">${esc(u.role)}</span>
            <span class="tag">${esc(String(u.rarity))}★</span>
          </div>
          <div class="detail-sub">번뜩임 카드: spark_1 ~ spark_4 (클릭 시 5종 선택) · spark_5는 변형 없음</div>
        </div>
      </div>

      <div class="section">
        <h3>카드</h3>
        <div class="unit-cards-grid">${cardGrid}</div>
      </div>
    </div>
  `;

  // Click: open spark picker when clicking spark cards
  root.querySelectorAll('.unit-card-wrap.is-spark').forEach(el=>{
    el.addEventListener('click', (e)=>{
      e.preventDefault();
      const cardId = el.dataset.card || '';
      const card = cards.find(c=>c.id===cardId);
      if(!card) return;
      const sparkNo = Number(String(cardId).split('_')[1] || '0');
      if(sparkNo >= 5) return; // spark_5 has no transform
      openSparkPicker({
        sparkNo,
        imgSrc: card.img,
        cardName: card.name,
        cardType: card.type,
        cost: card.cost
      });
    });
  });
}

export function renderPartners(root, data){
  setTitle('파트너');
  root.innerHTML = `
    <div class="card"><div class="section">
      <div class="toolbar"><input class="input" id="q" placeholder="파트너 검색..." /></div>
      <div class="thumbGrid" id="grid"></div>
    </div></div>
  `;
  const state={q:''};
  function apply(){
    const q = state.q.trim().toLowerCase();
    const list = data.partners.items.filter(p=>!q || p.name.toLowerCase().includes(q));
    $('#grid', root).innerHTML = list.map(p=>`
      <div class="thumb" data-id="${esc(p.id)}">
        <div class="thumb__img">${esc(p.name)}</div>
        <div class="thumb__meta">
          <div class="thumb__title">${esc(p.name)}</div>
          <div class="thumb__sub">${esc(p.note||'')}</div>
        </div>
      </div>
    `).join('');
  }
  $('#q', root).addEventListener('input', e=>{state.q=e.target.value; apply();});
  root.addEventListener('click', e=>{
    const t = e.target.closest('.thumb'); if(!t) return;
    location.hash = `#/partners/${t.dataset.id}`;
  });
  apply();
}

export function renderPartnerDetail(root, data, id){
  const p = data.partners.items.find(x=>x.id===id);
  if(!p){ setTitle('파트너'); root.innerHTML = `<div class="card"><div class="section">없는 파트너입니다.</div></div>`; return;}
  setTitle(p.name);
  root.innerHTML = `
    <div class="grid" style="gap:14px">
      <div class="card"><div class="section">
        <div style="display:flex; justify-content:space-between; gap:10px">
          <div>
            <div style="font-size:22px; font-weight:1000">${esc(p.name)}</div>
            <div class="muted" style="margin-top:6px">${esc(p.note || '')}</div>
          </div>
          <a class="iconbtn" href="#/partners">목록</a>
        </div>
      </div></div>

      <div class="card"><div class="section">
        <h2>능력</h2>
        <div class="muted" style="white-space:pre-wrap">${esc(p.abilityText || '')}</div>
      </div></div>

      <div class="card"><div class="section">
        <h2>에고 스킬</h2>
        <div style="font-weight:900">${esc(p.egoSkill?.name || '')}</div>
        <div class="muted" style="margin-top:8px; white-space:pre-wrap">${esc(p.egoSkill?.text || '')}</div>
      </div></div>
    </div>
  `;
}

export function renderChaos(root, data){
  setTitle('카오스');
  root.innerHTML = `
    <div class="card"><div class="section">
      <h2>카오스 목록</h2>
      <div class="grid cols-3" id="list"></div>
    </div></div>
  `;
  $('#list', root).innerHTML = data.chaos.items.map(c=>`
    <a class="card" href="#/chaos/${esc(c.id)}" style="padding:14px; display:block">
      <div style="font-weight:900">${esc(c.name)}</div>
      <div class="muted" style="margin-top:6px; font-size:12px">${esc(c.summary || '')}</div>
      <div style="margin-top:10px; display:flex; gap:8px; flex-wrap:wrap">
        ${(c.goodElements||[]).map(e=>`<span class="badge">${esc(e)}</span>`).join('')}
      </div>
    </a>
  `).join('');
}

export function renderChaosDetail(root, data, id){
  const c = data.chaos.items.find(x=>x.id===id);
  if(!c){ setTitle('카오스'); root.innerHTML = `<div class="card"><div class="section">없는 카오스입니다.</div></div>`; return;}
  setTitle(c.name);

  const mkCards = (arr, kind)=>`
    <div class="deckGrid">
      ${arr.map(it=>`
        <div class="miniCard" data-open="${esc(it.id)}" data-kind="${esc(kind)}">
          <div class="miniCard__title">${esc(it.name)}</div>
          <div class="miniCard__sub">${esc(it.tooltip || '')}</div>
        </div>
      `).join('')}
    </div>
  `;

  root.innerHTML = `
    <div class="row">
      <div class="flex3">
        <div class="grid" style="gap:14px">
          <div class="card"><div class="section">
            <div style="display:flex; justify-content:space-between; gap:10px">
              <div>
                <div style="font-size:22px; font-weight:1000">${esc(c.name)}</div>
                <div class="muted" style="margin-top:6px">${esc(c.summary || '')}</div>
              </div>
              <a class="iconbtn" href="#/chaos">목록</a>
            </div>
            <hr/>
            <div style="font-weight:900">추천 전투원 / 운영 팁</div>
            <div class="muted" style="margin-top:8px; white-space:pre-wrap">${esc(c.recommendText || '')}</div>
          </div></div>

          <div class="card" id="secCards"><div class="section">
            <h2>중립카드</h2>
            ${mkCards(c.neutralCards || [], 'neutral')}
          </div></div>

          <div class="card" id="secEvents"><div class="section">
            <h2>이벤트</h2>
            ${mkCards(c.events || [], 'event')}
          </div></div>

          <div class="card" id="secGear"><div class="section">
            <h2>카오스 장비</h2>
            ${mkCards(c.gear || [], 'gear')}
          </div></div>
        </div>
      </div>

      <div class="flex1">
        <div class="card" style="position:sticky; top:86px">
          <div class="section">
            <div style="font-weight:900; margin-bottom:10px">책갈피</div>
            <div class="grid" style="gap:10px">
              <button class="iconbtn" data-jump="secCards">중립카드</button>
              <button class="iconbtn" data-jump="secEvents">이벤트</button>
              <button class="iconbtn" data-jump="secGear">장비</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  root.addEventListener('click', (e)=>{
    const j = e.target.closest('[data-jump]');
    if(j){
      const id = j.dataset.jump;
      document.getElementById(id)?.scrollIntoView({behavior:'smooth', block:'start'});
      return;
    }
    const it = e.target.closest('[data-open]');
    if(!it) return;
    const kind = it.dataset.kind;
    const pool = [...(c.neutralCards||[]), ...(c.events||[]), ...(c.gear||[])];
    const obj = pool.find(x=>x.id===it.dataset.open);
    if(!obj) return;
    openModal(obj.name, `
      <div class="card" style="padding:12px">
        <div class="muted" style="margin-bottom:8px">종류: ${esc(kind)}</div>
        <div class="muted" style="white-space:pre-wrap">${esc(obj.text || obj.tooltip || '')}</div>
      </div>
    `);
  });
}

export function renderGuides(root, data, id){
  setTitle('가이드');
  const tags = ['시즌','카오스','대균열','성장','시스템'];
  const state={q:'', tag:'all'};

  function filtered(){
    const q = state.q.trim().toLowerCase();
    return [...data.guides.items]
      .filter(g=>{
        if(state.tag!=='all' && g.tag!==state.tag) return false;
        if(q && !(g.title.toLowerCase().includes(q) || (g.summary||'').toLowerCase().includes(q))) return false;
        return true;
      })
      .sort((a,b)=> new Date(b.updatedAt) - new Date(a.updatedAt));
  }

  function renderList(){
    $('#list', root).innerHTML = filtered().map(g=>`
      <a class="card" href="#/guides/${esc(g.id)}" style="padding:14px; display:block">
        <div style="display:flex; justify-content:space-between; gap:10px">
          <div style="font-weight:900">${esc(g.title)}</div>
          <span class="badge">${esc(g.tag)}</span>
        </div>
        <div class="muted" style="margin-top:6px; font-size:12px">${esc(g.summary||'')}</div>
        <div class="muted" style="margin-top:8px; font-size:11px">업데이트: ${esc(g.updatedAt)}</div>
      </a>
    `).join('');
  }

  const detail = id ? data.guides.items.find(x=>x.id===id) : null;

  root.innerHTML = `
    <div class="row">
      <div class="flex2">
        <div class="card"><div class="section">
          <div class="toolbar"><input class="input" id="q" placeholder="가이드 검색..." /></div>
          <div class="chips" id="chips">
            <div class="chip active" data-tag="all">전체</div>
            ${tags.map(t=>`<div class="chip" data-tag="${esc(t)}">${esc(t)}</div>`).join('')}
          </div>
          <div class="grid" id="list" style="margin-top:12px; gap:12px"></div>
        </div></div>
      </div>
      <div class="flex3">
        <div class="card"><div class="section">
          ${detail ? `
            <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start">
              <div>
                <div style="font-size:20px; font-weight:1000">${esc(detail.title)}</div>
                <div class="muted" style="margin-top:6px; font-size:12px">태그: ${esc(detail.tag)} · 업데이트: ${esc(detail.updatedAt)}</div>
              </div>
              <a class="iconbtn" href="#/guides">닫기</a>
            </div>
            <hr/>
            <div style="white-space:pre-wrap">${esc(detail.content || '')}</div>
          ` : `<div class="muted">왼쪽에서 글을 선택하면 여기에서 내용을 봅니다.</div>`}
        </div></div>
      </div>
    </div>
  `;

  $('#q', root).addEventListener('input', e=>{state.q=e.target.value; renderList();});
  $('#chips', root).addEventListener('click', e=>{
    const c = e.target.closest('.chip'); if(!c) return;
    $$('.chip', root).forEach(x=>x.classList.remove('active'));
    c.classList.add('active');
    state.tag = c.dataset.tag;
    renderList();
  });
  renderList();
}

export function renderCards(root, data){
  setTitle('카드');
  const state={q:'', type:'all', source:'all'};
  const types = ['all','공격','스킬','강화'];
  const sources = ['all','전투원','중립','몬스터'];

  function filtered(){
    const q = state.q.trim().toLowerCase();
    return data.cards.items.filter(c=>{
      if(state.type!=='all' && c.type!==state.type) return false;
      if(state.source!=='all' && c.source!==state.source) return false;
      if(q && !c.name.toLowerCase().includes(q)) return false;
      return true;
    });
  }
  function render(){
    const all = filtered();
    $('#grid', root).innerHTML = all.slice(0,200).map(renderCardMini).join('');
    $('#count', root).textContent = `${all.length}개`;
  }

  root.innerHTML = `
    <div class="card"><div class="section">
      <div class="toolbar">
        <input class="input" id="q" placeholder="카드 이름 검색..." />
        <select id="type">${types.map(t=>`<option value="${esc(t)}">${esc(t==='all'?'종류 전체':t)}</option>`).join('')}</select>
        <select id="source">${sources.map(t=>`<option value="${esc(t)}">${esc(t==='all'?'출처 전체':t)}</option>`).join('')}</select>
        <span class="badge" id="count"></span>
      </div>
      <div class="deckGrid" id="grid"></div>
      <div class="muted" style="margin-top:12px; font-size:12px">성능 때문에 최대 200개까지만 렌더링(필터/검색으로 좁혀서 사용).</div>
    </div></div>
  `;

  $('#q', root).addEventListener('input', e=>{state.q=e.target.value; render();});
  $('#type', root).addEventListener('change', e=>{state.type=e.target.value; render();});
  $('#source', root).addEventListener('change', e=>{state.source=e.target.value; render();});

  root.addEventListener('click', (e)=>{
    const card = e.target.closest('[data-card]');
    if(!card) return;
    const c = data.cards.items.find(x=>x.id===card.dataset.card);
    if(!c) return;
    openModal(c.name, `
      <div class="card" style="padding:12px">
        <div style="display:flex;justify-content:space-between;gap:10px">
          <div style="font-weight:900">${esc(c.name)}</div>
          <span class="badge">${esc(c.type)} · ${esc(c.cost)}</span>
        </div>
        <div class="muted" style="margin-top:8px; white-space:pre-wrap">${esc(c.text||'')}</div>
      </div>
    `);
  });
  render();
}

const DIVINE_OPTIONS = [
  '비용 -1',
  '드로우 +1(스킬)',
  '행동 포인트 +1(공/스)',
  '사기 +1(강화)',
  '결의 +1(강화)',
  '취약 2(공격)',
  '고통 4(공격)',
  '강인도 피해 100%(공격)',
  '항상 약점 공격(공격)',
  '무작위 아군 협공(공/스)',
  '피해량 30% 증가(공격)',
  '치유량 30% 증가(치유 스킬)',
  '실드량 30% 증가(실드 관련)'
];

export function renderDeckbuilder(root, data){
  setTitle('덱빌더');
  const state = { unitId: data.units.items[0]?.id || '', deck: [] };

  function unit(){ return data.units.items.find(u=>u.id===state.unitId); }
  function unitCards(){
    const u = unit(); if(!u) return [];
    return u.cards.map(cid=>data.cards.items.find(c=>c.id===cid)).filter(Boolean);
  }
  function neutralCards(){ return data.cards.items.filter(c=>c.source==='중립').slice(0,60); }

  function renderDeck(){
    $('#deckGrid', root).innerHTML = state.deck.map((d, idx)=>{
      const c = data.cards.items.find(x=>x.id===d.cardId);
      const shimmerText = d.shimmerVariantIndex!=null ? `번뜩임:${c?.shimmer?.variants?.[d.shimmerVariantIndex]?.name||''}` : '';
      const divineText = d.divineIndex!=null ? `신:${DIVINE_OPTIONS[d.divineIndex]||''}` : '';
      return `
        <div class="miniCard" data-deck-idx="${idx}" title="우클릭: 번뜩임/신 번뜩임 · 클릭: 상세">
          <div class="miniCard__pill">${esc(c?.type||'?')} · ${esc(c?.cost||'?')}</div>
          <div class="miniCard__title">${esc(c?.name||'?')}</div>
          <div class="miniCard__sub">${esc([shimmerText, divineText].filter(Boolean).join(' / ') || (c?.tooltip||''))}</div>
        </div>
      `;
    }).join('');
    $('#deckCount', root).textContent = `${state.deck.length}장`;
  }

  function renderPools(){
    $('#poolUnit', root).innerHTML = unitCards().map(c=>`
      <div class="miniCard" data-card="${esc(c.id)}">
        <div class="miniCard__pill">${esc(c.type)} · ${esc(c.cost)}</div>
        <div class="miniCard__title">${esc(c.name)}</div>
        <div class="miniCard__sub">${esc(c.tooltip||'')}</div>
      </div>
    `).join('');
    $('#poolNeutral', root).innerHTML = neutralCards().map(c=>`
      <div class="miniCard" data-card="${esc(c.id)}">
        <div class="miniCard__pill">${esc(c.type)} · ${esc(c.cost)}</div>
        <div class="miniCard__title">${esc(c.name)}</div>
        <div class="miniCard__sub">${esc(c.tooltip||'')}</div>
      </div>
    `).join('');
  }

  function addCard(cardId){ state.deck.push({cardId, shimmerVariantIndex:null, divineIndex:null}); renderDeck(); }

  root.innerHTML = `
    <div class="grid" style="gap:14px">
      <div class="card"><div class="section">
        <div class="toolbar">
          <select id="unitSel">${data.units.items.map(u=>`<option value="${esc(u.id)}">${esc(u.name)} (${esc(u.element)} · ${esc(u.job)} · ${esc(u.rarity)}★)</option>`).join('')}</select>
          <span class="badge" id="deckCount"></span>
          <button class="iconbtn" id="clearDeck">덱 비우기</button>
        </div>
        <div class="deckBox">
          <div class="deckGrid" id="deckGrid"></div>
          <div class="muted" style="margin-top:10px; font-size:12px">덱 박스 카드: 우클릭 → 번뜩임/신 번뜩임 선택</div>
        </div>
      </div></div>

      <div class="card"><div class="section">
        <div class="tabs" id="tabs">
          <div class="tab active" data-tab="unit">전투원 카드</div>
          <div class="tab" data-tab="neutral">중립카드</div>
        </div>
        <div id="tab_unit" style="margin-top:12px"><div class="deckGrid" id="poolUnit"></div></div>
        <div id="tab_neutral" class="hidden" style="margin-top:12px"><div class="deckGrid" id="poolNeutral"></div></div>
      </div></div>
    </div>
  `;

  $('#unitSel', root).value = state.unitId;
  $('#unitSel', root).addEventListener('change', e=>{ state.unitId = e.target.value; state.deck=[]; renderPools(); renderDeck(); });
  $('#clearDeck', root).addEventListener('click', ()=>{ state.deck=[]; renderDeck(); });
  $('#tabs', root).addEventListener('click', e=>{
    const t = e.target.closest('.tab'); if(!t) return;
    $$('.tab', root).forEach(x=>x.classList.remove('active')); t.classList.add('active');
    const k=t.dataset.tab;
    $('#tab_unit', root).classList.toggle('hidden', k!=='unit');
    $('#tab_neutral', root).classList.toggle('hidden', k!=='neutral');
  });

  root.addEventListener('click', e=>{
    const c = e.target.closest('[data-card]');
    if(c){ addCard(c.dataset.card); return; }
    const d = e.target.closest('[data-deck-idx]');
    if(d){
      const idx = Number(d.dataset.deckIdx);
      const cardId = state.deck[idx]?.cardId;
      const card = data.cards.items.find(x=>x.id===cardId);
      if(card) openModal(card.name, `<div class="card" style="padding:12px"><div class="muted" style="white-space:pre-wrap">${esc(card.text||'')}</div></div>`);
      return;
    }
  });

  root.addEventListener('contextmenu', e=>{
    const d = e.target.closest('[data-deck-idx]');
    if(!d) return;
    e.preventDefault();
    const idx = Number(d.dataset.deckIdx);
    const entry = state.deck[idx];
    const c = data.cards.items.find(x=>x.id===entry.cardId);
    const items = [];
    if(c?.shimmer?.variants?.length){
      items.push({label:'번뜩임 선택(초기화)', right:'', onClick:()=>{entry.shimmerVariantIndex=null; renderDeck();}});
      c.shimmer.variants.forEach((v,i)=>items.push({label:`번뜩임: ${v.name}`, right: entry.shimmerVariantIndex===i?'✓':'', onClick:()=>{entry.shimmerVariantIndex=i; renderDeck();}}));
    } else items.push({label:'번뜩임 없음', right:'', onClick:()=>{}});
    items.push({label:'—', right:'', onClick:()=>{}});
    items.push({label:'신 번뜩임(초기화)', right:'', onClick:()=>{entry.divineIndex=null; renderDeck();}});
    DIVINE_OPTIONS.forEach((opt,i)=>items.push({label:`신: ${opt}`, right: entry.divineIndex===i?'✓':'', onClick:()=>{entry.divineIndex=i; renderDeck();}}));
    items.push({label:'—', right:'', onClick:()=>{}});
    items.push({label:'덱에서 제거', right:'Del', onClick:()=>{state.deck.splice(idx,1); renderDeck();}});
    showCtxMenu({x:e.clientX,y:e.clientY,items});
  });

  renderPools(); renderDeck();
}

function calcPTFromState(calc){
  let pt = 0;
  pt += (calc.neutralCount||0) * 20;
  for(const m of (calc.monsters||[])){
    if(m.rarity==='일반') pt += 20;
    else if(m.rarity==='희귀') pt += 50;
    else if(m.rarity==='전설') pt += 80;
  }
  pt += (calc.divineOn || 0) * 20;
  for(const c of (calc.copies||[])){
    const n = c.count || 1;
    if(n > 2) pt += (n-2) * 40;
  }
  pt += (calc.startRemoved || 0) * 20;
  pt += (calc.reforgeCount || 0) * 10;
  pt += (calc.hammerCount || 0) * 10;
  return pt;
}

export function renderCalculator(root, data){
  setTitle('계산기(PT)');
  const state = {
    unitId: data.units.items[0]?.id || '',
    ownedExtra: [false,false,false,false],
    divine: {},
    shimmer: {},
    neutral: [],
    startRemoved: 0,
    copies: [],
    monsters: [],
    reforgeCount: 0,
    hammerCount: 0
  };

  function unit(){ return data.units.items.find(u=>u.id===state.unitId); }
  function unitCards(){
    const u = unit(); if(!u) return [];
    return u.cards.map(cid=>data.cards.items.find(c=>c.id===cid)).filter(Boolean);
  }

  function recompute(){
    const cards = unitCards();
    const shimmerCardIds = new Set(cards.slice(3,7).map(c=>c.id));
    let divineOn = 0;
    for(const cid of Object.keys(state.divine)){
      if(shimmerCardIds.has(cid)) divineOn += 1;
    }
    for(const n of state.neutral){
      if(n.divineIndex!=null) divineOn += 1;
    }
    const pt = calcPTFromState({
      neutralCount: state.neutral.length,
      monsters: state.monsters,
      divineOn,
      startRemoved: state.startRemoved,
      copies: state.copies,
      reforgeCount: state.reforgeCount,
      hammerCount: state.hammerCount
    });
    $('#ptValue', root).textContent = `${pt} PT`;
  }

  function pickNeutral(){
    const list = data.cards.items.filter(c=>c.source==='중립').slice(0,120);
    openModal('중립카드 추가', `
      <div class="muted" style="margin-bottom:10px">카드를 클릭하면 추가됩니다.</div>
      <div class="deckGrid">${list.map(c=>`<div class="miniCard" data-pick="${esc(c.id)}"><div class="miniCard__pill">${esc(c.type)} · ${esc(c.cost)}</div><div class="miniCard__title">${esc(c.name)}</div><div class="miniCard__sub">${esc(c.tooltip||'')}</div></div>`).join('')}</div>
    `);
    const mb = document.getElementById('modalBody');
    mb.addEventListener('click', (e)=>{
      const p = e.target.closest('[data-pick]'); if(!p) return;
      state.neutral.push({cardId:p.dataset.pick, shimmerVariantIndex:null, divineIndex:null});
      render();
    }, {once:true});
  }

  function render(){
    const cards = unitCards();
    const shimmerIdx = new Set([3,4,5,6]); // 4~7
    root.innerHTML = `
      <div class="grid" style="gap:14px">
        <div class="card"><div class="section">
          <div class="toolbar">
            <select id="unitSel">${data.units.items.map(u=>`<option value="${esc(u.id)}">${esc(u.name)} (${esc(u.element)} · ${esc(u.job)} · ${esc(u.rarity)}★)</option>`).join('')}</select>
            <div class="pill" id="ptValue">0 PT</div>
          </div>
          <div class="muted" style="font-size:12px">우클릭: 번뜩임/신 번뜩임 (4~7번 카드 + 중립카드)</div>
        </div></div>

        <div class="card"><div class="section">
          <h2>전투원 카드</h2>
          <div class="grid cols-4" id="unitCardGrid">
            ${cards.map((c,idx)=>{
              const isShimmer = shimmerIdx.has(idx) && c.shimmer?.variants?.length;
              const enabled = idx<4 ? true : state.ownedExtra[idx-4];
              const dim = enabled ? '' : 'opacity:.45; filter:grayscale(1)';
              const sub = [];
              if(state.shimmer[c.id]!=null && isShimmer) sub.push(`번뜩임:${c.shimmer.variants[state.shimmer[c.id]]?.name||''}`);
              if(state.divine[c.id]!=null) sub.push(`신:${DIVINE_OPTIONS[state.divine[c.id]]||''}`);
              return `
                <div class="card" style="padding:12px; ${dim}; cursor:${enabled?'pointer':'not-allowed'}"
                     data-unit-card="${esc(c.id)}" data-enabled="${enabled?1:0}" data-idx="${idx}">
                  <div style="display:flex;justify-content:space-between;gap:10px">
                    <div style="font-weight:900">${esc(idx+1)}. ${esc(c.name)}</div>
                    <span class="badge">${esc(c.type)} · ${esc(c.cost)}</span>
                  </div>
                  <div class="muted" style="margin-top:8px; font-size:12px">${esc(sub.join(' / ') || c.tooltip || '')}</div>
                  ${idx>=4?`<div class="muted" style="margin-top:10px; font-size:11px">클릭: 획득/미획득 토글</div>`:''}
                </div>
              `;
            }).join('')}
          </div>
        </div></div>

        <div class="card"><div class="section">
          <h2>중립카드</h2>
          <div class="toolbar">
            <button class="iconbtn" id="addNeutral">+ 중립카드 추가</button>
            <span class="badge" id="neutralCount">${state.neutral.length}장</span>
          </div>
          <div class="deckGrid" id="neutralGrid">
            ${state.neutral.map((n,idx)=>{
              const c = data.cards.items.find(x=>x.id===n.cardId);
              const sub=[];
              if(n.shimmerVariantIndex!=null && c?.shimmer?.variants?.length) sub.push(`번뜩임:${c.shimmer.variants[n.shimmerVariantIndex]?.name||''}`);
              if(n.divineIndex!=null) sub.push(`신:${DIVINE_OPTIONS[n.divineIndex]||''}`);
              return `<div class="miniCard" data-neutral-idx="${idx}" title="우클릭: 번뜩임/신 번뜩임">${sub.length?`<div class="miniCard__pill">${esc(c.type)} · ${esc(c.cost)}</div>`:''}
                <div class="miniCard__pill">${esc(c?.type||'?')} · ${esc(c?.cost||'?')}</div>
                <div class="miniCard__title">${esc(c?.name||'?')}</div>
                <div class="miniCard__sub">${esc(sub.join(' / ') || c?.tooltip || '')}</div>
              </div>`;
            }).join('')}
          </div>
        </div></div>

        <div class="card"><div class="section">
          <h2>재련 / 신의 망치</h2>
          <div class="toolbar">
            <label class="muted">재련</label>
            <select id="reforgeSel">${[0,1,2,3].map(n=>`<option value="${n}">${n}회</option>`).join('')}</select>
            <label class="muted">신의 망치</label>
            <select id="hammerSel">${[0,1,2,3].map(n=>`<option value="${n}">${n}회</option>`).join('')}</select>
          </div>
        </div></div>

        <div class="card"><div class="section">
          <h2>시작카드 제거</h2>
          <div class="toolbar">
            <label class="muted">시작카드 제거</label>
            <select id="startRemoved">${[0,1,2,3,4,5].map(n=>`<option value="${n}">${n}장</option>`).join('')}</select>
          </div>
        </div></div>
      </div>
    `;

    $('#unitSel', root).value = state.unitId;
    $('#reforgeSel', root).value = String(state.reforgeCount);
    $('#hammerSel', root).value = String(state.hammerCount);
    $('#startRemoved', root).value = String(state.startRemoved);
    $('#neutralCount', root).textContent = `${state.neutral.length}장`;
    recompute();
  }

  render();

  root.addEventListener('click', (e)=>{
    if(e.target.closest('#addNeutral')){ pickNeutral(); return; }
    const uc = e.target.closest('[data-unit-card]');
    if(uc){
      const idx = Number(uc.dataset.idx);
      if(idx>=4){
        state.ownedExtra[idx-4] = !state.ownedExtra[idx-4];
        render();
        return;
      }
      return;
    }
  });

  root.addEventListener('change', (e)=>{
    if(e.target.id==='unitSel'){
      state.unitId = e.target.value;
      state.ownedExtra=[false,false,false,false];
      state.divine={}; state.shimmer={}; state.neutral=[];
      render();
      return;
    }
    if(e.target.id==='reforgeSel'){ state.reforgeCount = Number(e.target.value); recompute(); }
    if(e.target.id==='hammerSel'){ state.hammerCount = Number(e.target.value); recompute(); }
    if(e.target.id==='startRemoved'){ state.startRemoved = Number(e.target.value); recompute(); }
  });

  root.addEventListener('contextmenu', (e)=>{
    const uc = e.target.closest('[data-unit-card]');
    if(uc){
      const idx = Number(uc.dataset.idx);
      const cid = uc.dataset.unitCard;
      const enabled = uc.dataset.enabled==='1';
      if(!enabled) return;
      if(idx < 3 || idx > 6) return; // 4~7
      e.preventDefault();
      const c = data.cards.items.find(x=>x.id===cid);
      const items = [];
      if(c?.shimmer?.variants?.length){
        items.push({label:'번뜩임(초기화)', right:'', onClick:()=>{delete state.shimmer[cid]; render();}});
        c.shimmer.variants.forEach((v,i)=>items.push({label:`번뜩임: ${v.name}`, right: state.shimmer[cid]===i?'✓':'', onClick:()=>{state.shimmer[cid]=i; render();}}));
      } else items.push({label:'번뜩임 없음', right:'', onClick:()=>{}});
      items.push({label:'—', right:'', onClick:()=>{}});
      items.push({label:'신 번뜩임(초기화)', right:'', onClick:()=>{delete state.divine[cid]; render();}});
      DIVINE_OPTIONS.forEach((opt,i)=>items.push({label:`신: ${opt}`, right: state.divine[cid]===i?'✓':'', onClick:()=>{state.divine[cid]=i; render();}}));
      showCtxMenu({x:e.clientX,y:e.clientY,items});
      return;
    }

    const n = e.target.closest('[data-neutral-idx]');
    if(n){
      e.preventDefault();
      const idx = Number(n.dataset.neutralIdx);
      const entry = state.neutral[idx];
      const c = data.cards.items.find(x=>x.id===entry.cardId);
      const items = [];
      if(c?.shimmer?.variants?.length){
        items.push({label:'번뜩임(초기화)', right:'', onClick:()=>{entry.shimmerVariantIndex=null; render();}});
        c.shimmer.variants.forEach((v,i)=>items.push({label:`번뜩임: ${v.name}`, right: entry.shimmerVariantIndex===i?'✓':'', onClick:()=>{entry.shimmerVariantIndex=i; render();}}));
      } else items.push({label:'번뜩임 없음', right:'', onClick:()=>{}});
      items.push({label:'—', right:'', onClick:()=>{}});
      items.push({label:'신 번뜩임(초기화)', right:'', onClick:()=>{entry.divineIndex=null; render();}});
      DIVINE_OPTIONS.forEach((opt,i)=>items.push({label:`신: ${opt}`, right: entry.divineIndex===i?'✓':'', onClick:()=>{entry.divineIndex=i; render();}}));
      items.push({label:'—', right:'', onClick:()=>{}});
      items.push({label:'삭제', right:'Del', onClick:()=>{state.neutral.splice(idx,1); render();}});
      showCtxMenu({x:e.clientX,y:e.clientY,items});
    }
  });
}

export function renderNotFound(root){
  setTitle('404');
  root.innerHTML = `<div class="card"><div class="section">페이지를 찾을 수 없습니다.</div></div>`;
}
