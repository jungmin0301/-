
let cache = new Map();
export async function loadJSON(path){
  if(cache.has(path)) return cache.get(path);
  const res = await fetch(path, {cache:'no-store'});
  if(!res.ok) throw new Error(`Failed to load ${path}: ${res.status}`);
  const data = await res.json();
  cache.set(path, data);
  return data;
}
export async function getAllData(){
  const [units, partners, chaos, guides, cards, config] = await Promise.all([
    loadJSON('data/units.json'),
    loadJSON('data/partners.json'),
    loadJSON('data/chaos.json'),
    loadJSON('data/guides.json'),
    loadJSON('data/cards.json'),
    loadJSON('data/config.json')
  ]);
  return {units, partners, chaos, guides, cards, config};
}
export function clearCache(){ cache = new Map(); }
